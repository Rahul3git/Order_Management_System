from django.apps import AppConfig


class RegistersConfig(AppConfig):
    name = 'registers'
